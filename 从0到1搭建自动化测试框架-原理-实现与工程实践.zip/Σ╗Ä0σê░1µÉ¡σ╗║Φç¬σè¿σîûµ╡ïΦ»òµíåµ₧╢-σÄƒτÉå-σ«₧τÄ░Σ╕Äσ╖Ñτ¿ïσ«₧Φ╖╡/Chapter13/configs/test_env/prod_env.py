DOMAIN = "https://www.baidu.com"
Account = {"username": "kevin", "password": "iTesting"}

Lagou_url = 'https://www.lagou.com'

one_login_uri = 'https://ones.ai/project/api/project/auth/login'
one_home_page = 'https://ones.ai/project/#/home/project'
one_header = {
    "user-agent": "user-agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36",
    "content-type": "application/json"}

# 设置运行超时编码
run_time_out = 150


