DOMAIN = "https://www.baidu.com"
Account = {"username": "kevin", "password":"iTesting"}