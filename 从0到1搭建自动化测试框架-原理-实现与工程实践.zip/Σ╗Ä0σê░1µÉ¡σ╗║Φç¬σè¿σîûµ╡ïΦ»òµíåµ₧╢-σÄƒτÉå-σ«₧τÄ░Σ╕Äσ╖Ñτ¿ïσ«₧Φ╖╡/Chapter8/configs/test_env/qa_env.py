DOMAIN = "https://www.qa.baidu.com"
Account = {'username': "kevin", 'password': "iTesting"}