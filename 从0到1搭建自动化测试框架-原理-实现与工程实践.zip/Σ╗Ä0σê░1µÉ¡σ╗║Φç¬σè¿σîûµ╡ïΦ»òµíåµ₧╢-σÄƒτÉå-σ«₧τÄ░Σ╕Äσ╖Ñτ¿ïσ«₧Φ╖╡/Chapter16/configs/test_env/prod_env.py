DOMAIN = "https://www.baidu.com"
Account = {"username": "kevin", "password": "iTesting"}

# 设置运行超时编码
run_time_out = 15
