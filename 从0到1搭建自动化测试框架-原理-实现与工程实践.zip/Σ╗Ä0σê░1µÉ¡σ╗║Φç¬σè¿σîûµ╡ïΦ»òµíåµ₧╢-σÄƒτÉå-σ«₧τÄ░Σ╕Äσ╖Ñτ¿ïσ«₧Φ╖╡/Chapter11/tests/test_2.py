from configs.global_config import init, set_config, get_config



