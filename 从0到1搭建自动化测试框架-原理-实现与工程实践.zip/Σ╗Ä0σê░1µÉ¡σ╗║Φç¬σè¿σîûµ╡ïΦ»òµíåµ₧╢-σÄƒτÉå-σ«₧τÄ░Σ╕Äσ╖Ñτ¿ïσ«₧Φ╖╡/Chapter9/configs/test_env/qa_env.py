DOMAIN = "https://www.qa. baidu.com"
Account = {"username": "kevin_QA", "password":"iTesting"}