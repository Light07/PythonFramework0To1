import pytest


@pytest.fixture()
def setup():
    return "some other stuff"